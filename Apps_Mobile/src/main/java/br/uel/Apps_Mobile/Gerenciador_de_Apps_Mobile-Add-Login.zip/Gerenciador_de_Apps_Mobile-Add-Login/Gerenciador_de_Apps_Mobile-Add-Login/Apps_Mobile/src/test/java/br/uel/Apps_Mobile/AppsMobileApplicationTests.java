package br.uel.Apps_Mobile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppsMobileApplicationTests {

	@Test
	void contextLoads() {
	}

}
