package br.uel.Apps_Mobile.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.uel.Apps_Mobile.Model.Usuario;
import br.uel.Apps_Mobile.Repository.UsuarioRepository;

@Service
public class UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    public Usuario buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    public Usuario autenticar(String email, String senha) {
        return usuarioRepository.findByEmailAndSenha(email, senha);
    }

    public void adicionar(Usuario user) {
        usuarioRepository.save(user);
    }

    public Usuario atualizar(Usuario userRefresh) {
            Usuario user = usuarioRepository.findByEmail(userRefresh.getEmail());

            user.setNome(userRefresh.getNome());
            user.setSenha(userRefresh.getSenha());
            
            return usuarioRepository.save(user);
    }

    public void removerUser(String email) {
        if (!usuarioRepository.existsByEmail(email)){
            throw new RuntimeException("Usuário não encontrado com o email: " + email);
        }
        usuarioRepository.deleteByEmail(email);
    }

    
}
