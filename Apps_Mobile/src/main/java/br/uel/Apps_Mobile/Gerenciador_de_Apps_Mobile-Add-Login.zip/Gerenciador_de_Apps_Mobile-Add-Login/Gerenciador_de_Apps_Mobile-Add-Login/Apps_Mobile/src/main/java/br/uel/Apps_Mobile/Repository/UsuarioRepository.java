package br.uel.Apps_Mobile.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import br.uel.Apps_Mobile.Model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Usuario findByEmailAndSenha(String email, String senha);

    Usuario findByEmail(String email);

    boolean existsByEmail(String email);
    
    void deleteByEmail(String email);

}
