package br.uel.Apps_Mobile.Repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import br.uel.Apps_Mobile.Model.AppMobile;


public interface AppsMobileRepository extends JpaRepository<AppMobile, Long> {
    List<AppMobile> findByNomeContainingIgnoreCase(String nome, Sort sort);
}
