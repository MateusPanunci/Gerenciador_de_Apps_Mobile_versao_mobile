package br.uel.Apps_Mobile.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.uel.Apps_Mobile.Model.Usuario;
import br.uel.Apps_Mobile.Service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class UsuarioController{
    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/login")
    public String autenticar(@RequestParam String email, @RequestParam String senha, HttpSession session, Model model) {
        Usuario usuario = usuarioService.autenticar(email, senha);
        
        System.out.println("ola");
        if (usuario != null) {
            session.setAttribute("usuarioLogado", usuario);
            return "redirect:/apps";
        } else {
            model.addAttribute("error", "E-mail ou senha inválidos!");
            return "index";
        }
        
    }
    
    @GetMapping("/cadastro")
    public String abrirCadastroUser(Model model){
        model.addAttribute("usuario", new Usuario());
        return "contaUser";
    }
    
    @PostMapping("/cadastro")
    public String cadastrarUser(@Valid @ModelAttribute Usuario usuario,
                                BindingResult erros,
                                RedirectAttributes ra,
                                Model model)
    {
        if (erros.hasErrors()) {
            // model.addAttribute("usuario", usuario ); //Não estava dando certo sem criar uma nova model
            // String error = "";

            // //O th:error não estava funcionando também, achei essa maneira alternativa de informar o erro genericamente
            // for (FieldError erro : erros.getFieldErrors()) {
            //     error = "O campo \"" + erro.getField() + "\" foi preenchido incorretamente!";
            //     break;
            // }
            // ra.addFlashAttribute("error", error);
            return "contaUser";
        }
        try {
            usuarioService.adicionar(usuario);
            ra.addFlashAttribute("msg", "Usuário cadastrado!");
            return "redirect:/";
        } catch (DataIntegrityViolationException e) {
            ra.addFlashAttribute("error", "Já há um Usuário cadastrado com o email " + usuario.getEmail() + "!");
            return "redirect:/cadastro";
        }
        
    }


    @GetMapping("/apps/editarUser/{email}")
    public String abrirEdicaoConta(@PathVariable String email, Model model){
        model.addAttribute("usuario", usuarioService.buscarPorEmail(email));
        return "contaUser";
    }


    @PostMapping("/editarUser")
    public String editarUser(@Valid @ModelAttribute Usuario usuario,
                                BindingResult erros,
                                RedirectAttributes ra,
                                Model model)
    {
        if (erros.hasErrors()) {
            // model.addAttribute("usuario", usuario ); //Não estava dando certo sem criar uma nova model
            // String error = "";

            // //O th:error não estava funcionando também, achei essa maneira alternativa de informar o erro genericamente
            // for (FieldError erro : erros.getFieldErrors()) {
            //     error = "O campo \"" + erro.getField() + "\" foi preenchido incorretamente!";
            //     break;
            // }
            // ra.addFlashAttribute("error", error);
            return "contaUser";
        }
        try {
            usuarioService.atualizar(usuario);
            ra.addFlashAttribute("msg", "Usuário cadastrado!");
        } catch (DataIntegrityViolationException e) {
            ra.addFlashAttribute("error", "Já há um Usuário cadastrado com o email " + usuario.getEmail() + "!");
            return "contaUser";
        }
        return "redirect:/";
    }


    // @PostMapping("/cadastro")
    // public String autenticar(@RequestParam String nome, @RequestParam String email, @RequestParam String senha, HttpSession session, Model model) {
    //     Usuario usuario = usuarioService.autenticar(email, senha);

    //     if (usuario != null) {
    //         session.setAttribute("usuarioexiste", "Usuário Já Existe!");
    //         return "redirect:/";
    //     } else {
    //         Usuario novo = Usuario
    //         model.addAttribute("error", "E-mail ou senha inválidos!");
    //         return "redirect:/";
    //     }
    // }



    @PostMapping("/apps/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @DeleteMapping("/usuarios/{email}")
    public String excluir(@PathVariable String email,
                          RedirectAttributes ra) {
        try {
            usuarioService.removerUser(email);
            ra.addFlashAttribute("success", "Conta excluída!");
            return "redirect:/";
        } catch (RuntimeException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/apps";
        }  
    }
}
